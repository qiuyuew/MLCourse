import numpy as np
import pandas as pd
from sklearn.decomposition import NMF
import matplotlib.pyplot as plt

# read a dense matrix directly from the file
df = pd.read_csv('rating_dense.csv', sep=',', header=None)
rate_matrix = df.values
print rate_matrix

# read a sparse matrix from the file and transfer it into a dense matrix
# df = pd.read_csv('rating_sparse.csv', sep=',', header=None)
# rows = df[0]
# columns = df[1]
# values = df[2]
# print rows, columns, values
# row_size = max(rows)+1
# column_size = max(columns)+1
# rate_matrix = np.zeros((row_size, column_size))
# for i in xrange(len(rows)):
# 	rate_matrix[rows[i]][columns[i]] = values[i]
# print rate_matrix


# Create a nmf model, set the number of hidden topics as 2
nmf = NMF(n_components=2)
# training process
user_distribution = nmf.fit_transform(rate_matrix)
item_distribution = nmf.components_

# print the learned hidden vectors of users and items
item_distribution = item_distribution.T
print "Item's topic distribution:"
print item_distribution
print "User's topic distribution:"
print user_distribution


# plot the items' distribution
plt.plot(item_distribution[:, 0], item_distribution[:, 1], "b*")
plt.xlim((-1, 3))
plt.ylim((-1, 3))

plt.title(u'the distribution of items (NMF)')
count = 1
for item in item_distribution:
    plt.text(item[0], item[1], 'item '+str(count), bbox=dict(facecolor='red', alpha=0.2))
    count += 1

plt.show()

# plot the users' distribution
user_names = ['Ben', 'Tom', 'John', 'Fred']
zip_data = zip(user_names, user_distribution)

plt.plot(user_distribution[:, 0], user_distribution[:, 1], "r^")
plt.xlim((-1, 3))
plt.ylim((-1, 4))
plt.title(u'the distribution of users (NMF)')
for item in zip_data:
    user_name = item[0]
    data = item[1]
    plt.text(data[0], data[1], user_name, bbox=dict(facecolor='green', alpha=0.2))

plt.show()

# change rate matrix 
rate_matrix[1, 2] = 0
print 'New rating matrix'
print rate_matrix

nmf = NMF(n_components=2)
user_distribution = nmf.fit_transform(rate_matrix)
item_distribution = nmf.components_

reconstruct_matrix = np.dot(user_distribution, item_distribution)
# less than zero
filter_matrix = rate_matrix < 1e-6  
print 'Reconstruct matrix, and filter the items with ratings:'
print reconstruct_matrix*filter_matrix

# To handle a new user
bob = [5, 5, 0, 0, 0, 5]
print "Bob's topic distribution:"
bob_distribution =  nmf.transform(bob)[0]
print bob_distribution


# plot the users' distribution with bob's
user_names = ['Ben', 'Tom', 'John', 'Fred']
zip_data = zip(user_names, user_distribution)

plt.plot(user_distribution[:, 0], user_distribution[:, 1], "r^")
plt.xlim((-1, 3))
plt.ylim((-1, 4))
plt.title(u'the distribution of users (NMF)')
for item in zip_data:
    user_name = item[0]
    data = item[1]
    plt.text(data[0], data[1], user_name, bbox=dict(facecolor='green', alpha=0.2))
plt.plot(bob_distribution[0], bob_distribution[1], "bo")
plt.text(bob_distribution[0], bob_distribution[1], "Bob", bbox=dict(facecolor='red', alpha=0.2))

plt.show()


