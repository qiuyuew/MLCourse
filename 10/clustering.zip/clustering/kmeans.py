import pandas as pd 
from sklearn.cluster import KMeans
from sklearn.decomposition import PCA
from sklearn import metrics
import matplotlib.pyplot as plt
import numpy as np

# Read in the csv file
df = pd.read_csv("city.csv") 

data = df.iloc[:,1:]
city_names = df.iloc[:,0]

cluster_num = 4

# Create a kmeans model on our data.  random_state helps ensure that the algorithm returns the same results each time.
kmeans_model = KMeans(n_clusters=cluster_num, random_state=1)

# training process
clustering_result = kmeans_model.fit(data)

# These are our fitted labels for clusters.
labels = clustering_result.labels_


# print clusters and the corresponding city names by pandas' libraries
print(pd.crosstab(labels, city_names))
# Group the city names according to their cluster labels, and print the relationships
group_city_names = [ [] for i in xrange(cluster_num)]
for i in xrange(len(labels)):
	label = labels[i]
	group_city_names[label].append(city_names[i])
for i in xrange(cluster_num):
	print "Cluster", i
	print group_city_names[i]

# Evaluate by Silhouette Coefficient
print('Silhouette Coefficient: %0.3f' % metrics.silhouette_score(data, labels))


# Turn the data into two columns with PCA
pca = PCA(cluster_num)
pca_data = pca.fit_transform(df.iloc[:,1:])
# Group the pca dataset according to their cluster labels
group_pcas = [ []  for i in xrange(cluster_num)]
for i in xrange(len(labels)):
	label = labels[i]
	group_pcas[label].append(pca_data[i])

# Plot the group of dataset
fig = plt.figure()
ax = fig.add_subplot(1,1,1,axisbg="1.0")
colors = ['r', 'g','y','m']
markers = ['o', '^', 's', 'x']
legends = ['cluster1', 'cluster2', 'cluster3', 'cluster4']
for i in xrange(cluster_num):
	array = np.asarray(group_pcas[i])
	ax.scatter(x=array[:,0], y=array[:,1], marker=markers[i], c=colors[i], label=legends[i])

plt.legend(loc=2)
plt.show()
