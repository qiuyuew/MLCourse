import pandas as pd 
import sklearn.cluster as skc
from sklearn import metrics
from sklearn import datasets
import matplotlib.pyplot as plt
import numpy as np

# Generate datasets. We choose the size big enough to see the scalability
# of the algorithms, but not too big to avoid too long running times
n_samples = 1500
noisy_circles = datasets.make_circles(n_samples=n_samples, factor=.5, noise=.05)
noisy_moons = datasets.make_moons(n_samples=n_samples, noise=.05)
x, y = noisy_moons

df = pd.read_csv("sample1_practise.csv") 
x = df.iloc[:,0:2]
y = df.iloc[:,2]

# Invoke DBSCAN to do cluster
db = skc.DBSCAN(eps=0.2, min_samples=10).fit(x)
# db = skc.KMeans(n_clusters=2, random_state=1).fit(x)

# Calculate and print the ratio of the noise data
labels = db.labels_
ratio=float(len(labels[labels[:] == -1])) / len(labels)
print('Noise ratio:', format(ratio, '.2%'))

# Calculate the number of clusters, and evaluate the performance of clustering results
n_clusters = len(set(labels)) - (1 if -1 in labels else 0)
print('Estimated number of clusters : %d' %n_clusters)
print('Silhouette Coefficient: %0.3f' % metrics.silhouette_score(x, labels))

# print cluster no and the correponding data sample
for i in range(n_clusters):
	print('Clsuter', i, ':')
	print(list(x[labels == i]))

# Evaluate by adjusted Rand Index
print('Adjusted Rand Index: %0.3f' % metrics.adjusted_rand_score(y, labels))


# Group the dataset according to their cluster labels
groups = [ []  for i in xrange(n_clusters)]
for i in xrange(len(labels)):
	label = labels[i]
	groups[label-1].append(x[i])

# Plot the group of dataset
fig = plt.figure()
ax = fig.add_subplot(1,1,1,axisbg="1.0")
colors = ['r', 'g','y','m']
markers = ['o', '^', 's', 'x']
legends = ['cluster1', 'cluster2', 'cluster3', 'cluster4']
for i in xrange(n_clusters):
	array = np.asarray(groups[i])
	ax.scatter(x=array[:,0], y=array[:,1], marker=markers[i], c=colors[i], label=legends[i])

plt.legend(loc=2)
plt.show()

